# -*- coding: utf-8 -*-
"""
Created on Sat Apr 10 18:34:35 2021
@author: admin

Программа создает набор фотографий с именами 1.jpg ,2.jpg и т. д. и записывает их 
в текущую директорию, то есть в ту, где находится сама программа. Поэтому, 
для создания изображений классов программу надо переносить в ту папку с именем класса,
для которого подготавливаются изображеия
"""

import cv2
import time

print( "ВЕРСИЯ OpenCV = ",cv2.__version__ )
cap = cv2.VideoCapture(0)
# cap.set(3,640) #width=640

k=7    # количество создаваемых изображений с web-камеры
if cap.isOpened():
    i=1
    while (i<k+1):
        w,frame = cap.read()
        ff=str(i)
        fname=ff+'.jpg'
        print(fname)
        cv2.imwrite(fname, frame)
        time.sleep(1)  # задержка, чтобы фото различались сильнее
        i=i+1
           